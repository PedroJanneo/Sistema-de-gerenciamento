<?php 
@session_start();
require_once('conexao.php');



//envio vazio
if(empty($_POST['usuario']) || empty($_POST['senha'])){
	header("location:index.php");
}

// Entrada de dados
$usuario = $_POST['usuario'];
$senha = hash('sha512',$_POST['senha']);

$usuario = trim($usuario);
$senha = trim($senha);

// Processamento de dados
$consulta = $pdo->prepare("SELECT * FROM funcionarios WHERE (email = :usuario OR funcional = :usuario ) AND senha = :senha");
$consulta->bindValue(":usuario", $usuario); 
$consulta->bindValue(":senha", $senha);
$consulta->execute();

$resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);
// Saída de dados

if(@count($resultado) > 0 ){
	// Verificar qual o nível do usuário para redirecionar para o painel correspondente
	$nivel = $resultado[0]['nivel'];
	if ($nivel == 'Administrador') {
		$_SESSION['nome_usuario'] = $resultado[0]['usuario'];
		$_SESSION['funcional_usuario'] = $resultado[0]['funcional'];
		echo "<script>window.location='painel-admin/index.php'</script>";
	}
}else{
	echo "<script>window.alert('Login inválido. Usuário ou senha incorreta')</script>";
	echo "<script>window.location='index.php'</script>";
	}
?>