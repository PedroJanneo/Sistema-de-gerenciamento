<?php 


$nome_sistema = 'Login';

$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = 'login-teste';


// $servidor = "localhost";
// $usuario = "taboao_escola_cultura";
// $senha = "5^cjNkfUKmu~";
// $banco = 'taboao_escola_cultura';

// // Variáveis Globais
// $nome_sistema = 'Login';

 ?>